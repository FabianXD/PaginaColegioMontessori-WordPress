<?php 

// Triggable?
$triggable = ( !empty( $option['triggable'] ) ) ? ' data-triggable="' . $option['triggable'] . '" class="schat-opts-triggable hide-if-js"' : ''; 

// Input type
$input_type = !empty( $option['input_type'] ) ? $option['input_type'] : 'text';

?>
<tr<?php echo $triggable; ?>>
	<th scope="row"><label for="schat-opts-field-<?php echo $option['id']; ?>"><?php echo $option['name']; ?></label></th>
	<td>

		<input type="<?php echo $input_type; ?>" value="<?php echo stripslashes( @$settings[$option['id']] ); ?>" name="<?php echo $option['id']; ?>" id="schat-opts-field-<?php echo $option['id']; ?>" class="regular-text" data-valid="<?php echo $valid; ?>" placeholder="<?php echo (!empty($option['placeholder'])) ? $option['placeholder'] : ''; ?>" />
		<?php echo '<a href="http://screets.org/apps/api/v1/keys/?domain=' . schat_current_domain() . '" class="button button-primary" target="_blank">' . __( 'Get your API key', 'schat' ) . '</a>'; ?>
		<p class="description"><?php echo $option['desc']; ?></p>

	</td>
</tr>
