<tr>
	<th scope="row">
		<label for="schat-opts-field-<?php echo $option['id']; ?>"><?php echo $option['name']; ?></label></th>
	<td>
		<input type="number" min="<?php echo $option['min']; ?>" max="<?php echo $option['max']; ?>" value="<?php echo $settings[$option['id']]; ?>" name="<?php echo $option['id']; ?>" id="schat-opts-field-<?php echo $option['id']; ?>" class="regular-text" style="width:80px" /> 
		<span class="schat-opts-units"><?php echo $option['units']; ?></span>
		<span class="description"><?php echo $option['desc']; ?></span>
	</td>
</tr>