<?php 

global $SCHAT;

$error_class = $error = '';

$triggable = ( !empty( $option['triggable'] ) ) ? ' data-triggable="' . $option['triggable'] . '" class="schat-opts-triggable hide-if-js"' : '';

// Error?
if( !empty( $SCHAT->admin_notices['fields'][$option['id']] ) ) {
	$error_class = 'schat-error-field';
	$error = '<div class="schat-error">' . $SCHAT->admin_notices['fields'][$option['id']] . '</div>';
}

?>
<tr<?php echo $triggable; ?>>
	<th scope="row"><label for="schat-opts-field-<?php echo $option['id']; ?>"><?php echo $option['name']; ?></label></th>
	<td>
		<textarea name="<?php echo $option['id']; ?>" id="schat-opts-field-<?php echo $option['id']; ?>" class="regular-text <?php echo $error_class; ?> schat-opts-textarea" rows="<?php echo ( isset( $option['rows'] ) ) ? $option['rows'] : 5; ?>"><?php echo stripslashes( $settings[$option['id']] ); ?></textarea>
		
		<?php echo $error; ?>

		<p class="description"><?php echo $option['desc']; ?></p>
	</td>
</tr>