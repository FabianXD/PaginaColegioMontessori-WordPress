<?php 

global $SCHAT;

$error_class = $error = '';

$triggable = ( !empty( $option['triggable'] ) ) ? ' data-triggable="' . $option['triggable'] . '" class="schat-opts-triggable hide-if-js"' : ''; 

// Error?
if( !empty( $SCHAT->admin_notices['fields'][$option['id']] ) ) {
	$error_class = 'schat-error-field';
	$error = '<div class="schat-error">' . $SCHAT->admin_notices['fields'][$option['id']] . '</div>';
}

?>
<tr<?php echo $triggable; ?>>
	<th scope="row">
		<label for="schat-opts-field-<?php echo $option['id']; ?>"><?php echo $option['name']; ?></label></th>
	<td>

		<?php if( !empty( $option['prefix'] ) ): ?>
			<small style="color:silver;" class="schat-opts-units"><?php echo $option['prefix']; ?></small>
		<?php endif; ?>
		
		<input type="text" value="<?php echo @$settings[$option['id']]; ?>" name="<?php echo $option['id']; ?>" id="schat-opts-field-<?php echo $option['id']; ?>" class="regular-text <?php echo $error_class; ?>" style="width:170px" placeholder="<?php echo $option['placeholder']; ?>" /> 
		
		<?php if( !empty( $option['suffix'] ) ): ?>
			<span class="schat-opts-units"><?php echo $option['suffix']; ?></span>
		<?php endif; ?>

		<?php echo $error; ?>

		<span class="description"><?php echo $option['desc']; ?></span>
	</td>
</tr>