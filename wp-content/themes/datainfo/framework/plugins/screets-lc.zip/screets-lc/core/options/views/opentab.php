<div class="schat-opts-pane hide-if-js">
	<table class="form-table">