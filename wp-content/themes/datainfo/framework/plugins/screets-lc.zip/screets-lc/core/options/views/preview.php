<?php $triggable = ( !empty( $option['triggable'] ) ) ? ' data-triggable="' . $option['triggable'] . '" class="schat-opts-triggable hide-if-js"' : ''; ?>
<tr<?php echo $triggable; ?>>
	<td colspan="2">
		<div class="schat_o_preview">
			
			<?php
			global $wp_version;

			// Show icons for WP 3.8+
			if( ( version_compare( $wp_version, '3.8', '>=' ) ) ): ?>
				<ul class="schat-preview-icons">
					<li id="ico_online_button" data-id="online_button" class="active" title="Button"><div class="dashicons dashicons-admin-links"></div></li>
					<!-- <li id="ico_offline_button"  data-id="offline_button" title="Button (Offline)"><div class="dashicons dashicons-editor-unlink"></div></li> -->
					<li id="ico_online"  data-id="online" title="Online Chat"><div class="dashicons dashicons-admin-comments"></div></li>
					<li id="ico_offline"  data-id="offline" title="Offline Form"><div class="dashicons dashicons-welcome-comments"></div></li>
				</ul>

				<div id="schat_preview_title">Button:</div>

			<?php 
			// Show select box for old WP versions
			else: ?>
				<select name="" id="" class="schat-preview">
					<option value="">-- None --</option>
					<option value="online_button" selected="selected">Button</option>
					<!-- <option value="offline_button">Button (Offline)</option> -->
					<option value="online">Online Chat</option>
					<option value="offline">Offline Form</option>
				</select>

			<?php endif; ?>
			
			<!-- Online Button -->
			<div id="SCHAT_preview_online_button" class="schat-preview-box _visible">
				<div class="schat-chat-btn schat-online-btn">
					<div class="schat-ico schat-ico-chat"></div>
					<div class="schat-ico _ico-arrow"></div>
					<div class="schat-title"></div>
				</div>
			</div>

			<!-- Offline Button -->
			<!-- <div id="SCHAT_preview_offline_button" class="schat-preview-box">
				<div class="schat-chat-btn schat-offline-btn">
					<div class="schat-ico schat-ico-chat"></div>
					<div class="schat-ico _ico-arrow"></div>
					<div class="schat-title"></div>
				</div>
			</div> -->


			<!-- Online -->
			<div id="SCHAT_preview_online" class="schat-preview-box">
				
				<div class="schat-widget">
					<div class="schat-online">
						<!-- Header -->
						<div class="schat-header"><div class="schat-title"></div><div class="schat-ico schat-ico-arrow-down"></div></div>
						
						<div class="schat-body">
							
							<div id="SCHAT_cnv_0">

								<!-- Reply form TOP -->
								<div id="SCHAT_reply_top" class="schat-cnv-reply" style="display: none;">
									<div class="schat-cnv-input">
										<textarea name="" class="schat-reply-input schat-autosize" placeholder="<?php echo $option['reply_ph']; ?>"></textarea>
									</div>
								</div>

								<!-- Conversation TOP -->
								<div id="SCHAT_cnv_top" class="schat-cnv" style="display: none;">

									<div class="schat-cnv-line">
										<div class="schat-avatar schat-img">
											<img src="<?php echo SCHAT_URL; ?>/assets/img/default-avatar.png" class="schat-company-avatar">
										</div>
										<div class="schat-cnv-msg">
											<div title="3 September 2014 0:56" class="schat-cnv-time">0:56</div>
											<div class="schat-cnv-author">Screets, Inc.:</div> 
											<span class="schat-cnv-msg-detail">Yes. The OS X operation system isn't susceptible to the thousands of viruses plaguing Windows-based computers</span>
										</div>
									</div>
									<div class="schat-clear"></div>

									<div class="schat-cnv-line schat-you">
										<div class="schat-avatar schat-img">
											<img src="<?php echo SCHAT_URL; ?>/assets/img/default-avatar.png">
										</div>
										<div class="schat-cnv-msg">
											<div title="3 September 2014 0:55" class="schat-cnv-time">0:55</div>
											<div class="schat-cnv-author">John Cash:</div> 
											<span class="schat-cnv-msg-detail">Hey! I wonder that a Mac is safe from PC viruses?</span>
										</div>
									</div>
									<div class="schat-clear"></div>
												
									<!-- Status message -->
									<!-- <div class="schat-cnv-line schat-cnv-status">screets has joined.</div> -->
									
								</div>
	
								<!-- Conversation BOTTOM -->
								<div id="SCHAT_cnv_bottom" class="schat-cnv" style="display: none;">
									
									<div class="schat-cnv-line schat-you">
										<div class="schat-avatar schat-img">
											<img src="<?php echo SCHAT_URL; ?>/assets/img/default-avatar.png">
										</div>
										<div class="schat-cnv-msg">
											<div title="3 September 2014 0:55" class="schat-cnv-time">0:55</div>
											<div class="schat-cnv-author">John Cash:</div> 
											<span class="schat-cnv-msg-detail">Hey! I wonder that a Mac is safe from PC viruses?</span>
										</div>
									</div>
									<div class="schat-clear"></div>

									<div class="schat-cnv-line">
										<div class="schat-avatar schat-img">
											<img src="<?php echo SCHAT_URL; ?>/assets/img/default-avatar.png" class="schat-company-avatar">
										</div>
										<div class="schat-cnv-msg">
											<div title="3 September 2014 0:56" class="schat-cnv-time">0:56</div>
											<div class="schat-cnv-author">Screets, Inc.:</div> 
											<span class="schat-cnv-msg-detail">Yes. The OS X operation system isn't susceptible to the thousands of viruses plaguing Windows-based computers</span>
										</div>
									</div>
									<div class="schat-clear"></div>

									
									
								</div>

								<div class="schat-tools">
									<a href="">End chat</a>
								</div>

								<!-- Reply form BOTTOM -->
								<div id="SCHAT_reply_bottom" class="schat-cnv-reply" style="display: none;">
									<form action="">
										<div class="schat-cnv-input">
											<textarea name=""  class="schat-reply-input schat-autosize" placeholder="<?php echo $option['reply_ph']; ?>"></textarea>
										</div>
									</form>
								</div>
							</div>
						</div>
				
					</div>
				</div>
			</div>

			<!-- Offline -->
			<div id="SCHAT_preview_offline" class="schat-preview-box">
				
				<div class="schat-widget">
					<div class="schat-offline">
						<!-- Header -->
						<div class="schat-header"><div class="schat-title"></div><div class="schat-ico schat-ico-arrow-down"></div></div>

						<!-- Offline form -->
						<div class="schat-body schat-form schat-offline-form">
							<div class="schat-lead"></div>

							<form action="">
								<div id="SCHAT_offline_row_name" class="schat-line">
									<label for="SCHAT_offline_f_name"><span id="SCHAT_offline_f_name_title" class="schat-title">Your name</span> <span class="schat-req">*</span>:</label>
									<input type="text" id="SCHAT_offline_f_name" placeholder="Your name">
								</div>

								<div id="SCHAT_offline_row_email" class="schat-line">
									<label for="SCHAT_offline_f_email"><span id="SCHAT_offline_f_email_title" class="schat-title">E-mail</span> <span class="schat-req">*</span>:</label>
									<input type="email" id="SCHAT_offline_f_email" placeholder="E-mail">
								</div>

								<div id="SCHAT_offline_row_phone" class="schat-line">
									<label for="SCHAT_offline_f_phone"><span id="SCHAT_offline_f_phone_title" class="schat-title">Phone</span> <span class="schat-req">*</span>:</label>
									<input type="email" id="SCHAT_offline_f_phone" placeholder="Phone">
								</div>

								<div id="SCHAT_offline_row_msg" class="schat-line">
									<label for="SCHAT_offline_f_msg"><span  id="SCHAT_offline_f_msg_title" class="schat-title">How can we help you?</span> <span class="schat-req">*</span>:</label>
									<textarea id="SCHAT_offline_f_msg" class="schat-autosize" placeholder="How can we help you?"></textarea>
								</div>

								<div class="schat-send">
									<a href="javascript:void(0)" id="SCHAT_offline_send" class="schat-form-btn">Send</a>
								</div>

							</form>
						</div>
					</div>
				</div>

			</div>

		<div class="schat-clear"></div>
		</div>
	</td>
</tr>