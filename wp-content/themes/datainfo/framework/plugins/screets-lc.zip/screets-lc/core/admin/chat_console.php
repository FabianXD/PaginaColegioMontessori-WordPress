<?php
/**
 * SCREETS © 2016
 *
 * Chat console template
 *
 * COPYRIGHT (c) 2016 Screets. All rights reserved.
 * This  is  commercial  software,  only  users  who have purchased a valid
 * license  and  accept  to the terms of the  License Agreement can install
 * and use this program.
 */

?>

<div id="SCHAT_console" class="schat-console">
	
	<div id="SCHAT_sidebar">
		<div class="schat-header">
			<?php _e( 'Users', 'schat' ); ?>
			<a href="" id="SCHAT_connect" class="schat-connect button button-small button-disabled"><?php _e( 'Please wait', 'schat' ); ?></a>
		</div>

		<div id="SCHAT_users">
			<div id="SCHAT_ls_ntf" style="color:#999; text-align: center; padding: 10px;">
				<?php _e( "Please wait", 'schat' ); ?>...
			</div>
		</div>

		<div class="schat-footer">
			&copy; <?php echo date( 'Y' ); ?> Screets. Screets Live Chat
		</div>
	</div>

	<div id="SCHAT_wall">
		<div id="SCHAT_tabs">
			<ul>
				<li class="schat-active"><a id="SCHAT_tab_username" href="javascript:void(0)">Screets CX</a></li>
			</ul>
		</div>
		
		<div class="schat-clear"></div>
		<div id="SCHAT_popup_content">
			<div id="SCHAT_popup_cnv" class="schat-popup-content schat-welcome"></div>
		</div>
</div>

<script>
	(function ($) {
		$(document).ready(function() {

			/**
			 * Set console window sizes
			 */
			$(window).resize(function() {

				var wpbody_h = $('#wpbody').height();

			}).trigger('resize');

		});
	} (window.jQuery || window.Zepto));
	
</script>